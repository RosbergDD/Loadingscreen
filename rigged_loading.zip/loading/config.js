
var play = false;
var myAudio = document.getElementById("leson");

myAudio.volume = 0.1;

function onKeyDown(event) {
        switch (event.keyCode) {
            case 32: //SpaceBar                    
                if (play) {
                    myAudio.pause();
                    play = false;
                } else {
                    myAudio.play();
                    play = true;
                }
                break;
        }
    return false;
}

window.addEventListener("keydown", onKeyDown, false);