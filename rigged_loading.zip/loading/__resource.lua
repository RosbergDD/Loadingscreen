resource_manifest_version '77731fab-63ca-442c-a67b-abc70f28dfa5'

files {
    "assets/fonts/pricedown.ttf",
    "assets/music.mp3",
    "assets/bg.jpg",
    'index.html',
    'style.css',
    'config.js'
}

loadscreen 'index.html'